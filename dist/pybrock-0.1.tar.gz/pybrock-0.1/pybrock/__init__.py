"""A library to organize snippets and helpers that I find useful. """

__version__ = '0.1'


from brock.utils import *
from brock.data import *
from brock.sports import *
