# brock

My personal python library to include snippets of code that I find helpful or do not want to keep reproducing from scratch.



## Notable packages included

- us
-- https://github.com/unitedstates/python-us

